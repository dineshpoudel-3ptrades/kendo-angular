const fs = require('fs');
const sass = require('sass');
const path = require('path');
const execa = require('execa');
const bundles = [
  './themes/light.scss',
  './themes/dark.scss',
  './themes/dim.scss',
  './frameworks/bootstrap/dark/bootstrap-dark.scss',
  './frameworks/bootstrap/light/bootstrap-light.scss',
  './frameworks/bootstrap/dim/bootstrap-dim.scss',
  './pro/abp/abp-bundle.scss',
  './pro/libraries/font-bundle.scss',
  './pro/side-menu/layout-bundle.scss',
  './pro/top-menu/layout-bundle.scss',
  './pro/public-website/layout-bundle.scss',
  './pro/libraries/ng-bundle.scss',
];

bundles.forEach(b => {
  const result = sass.compile(b, { sourceMap: false, loadPaths: ['./'], style: 'compressed' });
  const destination = './built/' + b.replace('.scss', '.css').split('./')[1];
  createFolderIfNotExists(path.dirname(destination) + '/');
  fs.writeFileSync(destination, result.css);
  rtlCommand(destination);
});

function rtlCommand(file) {
  execa(
    'npm',
    ['run', 'postcss', '--', file, '--config', './postcss.config.js', '--dir', path.dirname(file), '--ext', '.rtl.css'],
    { stdio: 'inherit' }
  );
}

function createFolderIfNotExists(destination) {
  destination.split('/').reduce((acc, dir) => {
    if (!fs.existsSync(acc)) {
      fs.mkdirSync(acc);
    }
    return `${acc}/${dir}`;
  });
}
